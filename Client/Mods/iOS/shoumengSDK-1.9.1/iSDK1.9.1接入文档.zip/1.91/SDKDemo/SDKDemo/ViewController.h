//
//  ViewController.h
//  SDKDemo
//
//  Created by 李振升 on 16/9/7.
//  Copyright (c) 2016年 武汉手盟网络科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>


#define OrientationIsPortrait   0  // 0 横屏   1竖屏

@interface ViewController : UIViewController

-(void) setTipText:(NSString *)text;

@end

