//
//  AppDelegate.h
//  SDKDemo
//
//  Created by 李振升 on 16/9/7.
//  Copyright (c) 2016年 武汉手盟网络科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property(nonatomic, readonly) ViewController* viewController;


@end

