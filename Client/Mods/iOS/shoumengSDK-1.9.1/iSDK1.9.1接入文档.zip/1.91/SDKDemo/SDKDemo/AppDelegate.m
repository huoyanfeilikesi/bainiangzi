//
//  AppDelegate.m
//  SDKDemo
//
//  Created by 李振升 on 16/9/7.
//  Copyright (c) 2016年 武汉手盟网络科技有限公司. All rights reserved.
//

#import "AppDelegate.h"
#import <SM910APP/SM910APP.h>

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    NSLog(@"11111  mainScreenRect:%@\napplicationFrame:%@",NSStringFromCGRect([[UIScreen mainScreen] bounds]),NSStringFromCGRect([UIScreen mainScreen].applicationFrame));
    _window = [[UIWindow alloc] initWithFrame: [[UIScreen mainScreen] bounds]];
    
    _viewController = [[ViewController alloc] initWithNibName:nil bundle:nil];
    
    
    // Set RootViewController to window
    if ( [[UIDevice currentDevice].systemVersion floatValue] < 6.0)
    {
        // warning: addSubView doesn't work on iOS6
        [_window addSubview: _viewController.view];
    }
    else
    {
        // use this method on ios6
        [_window setRootViewController:_viewController];
    }
    
    [_window makeKeyAndVisible];
    
    [[UIApplication sharedApplication] setStatusBarHidden:true];
    
#warning 设置为竖屏，请在初始化之前设置 YES为竖屏，NO或者不设为横屏
#if OrientationIsPortrait
    [[SDK910 sharedInstance] setOrientationIsPortrait:YES];
#endif
    
#warning 版号显示 请在加载资源的同时显示出来
    // 显示版号
    [[SDK910 sharedInstance] showTipView];
    
    // 初始化910SDK
    [[SDK910 sharedInstance] initSDKwithGameId:@"339" PakcageId:@"3380000" LoginCompletion:^(GenericStatus_t loginStatus, NSString *account, NSString *session) {
        if (loginStatus==kStatusSuccess) {
            NSLog(@"登陆成功:  登陆账号是:%@     sessionid是:%@",account,session);
            [_viewController setTipText:[NSString stringWithFormat:@"登录成功:%@",account]];
#warning 我这里是为了演示版号关闭，请CP在玩家点“进入游戏或者开始游戏”的时候再关闭
            [[SDK910  sharedInstance] dissMissTipView];
        }else{
            NSLog(@"登陆失败");
            [_viewController setTipText:@"登录失败"];
        }
    } LogoutCompletion:^{
        NSLog(@"登出");
        [_viewController setTipText:@"登出"];
        [[SDK910 sharedInstance] showMemberCenter];
#warning 注意：SDK在玩家用游客账号 登录的时候，会给玩家切换账号的按钮，如果游客账号登录后返回登录界面重新登录，再点返回按钮时会调用这里，一定要在这里对之前登录的游客账号进行销毁处理，换用正式账号登录成功的账号
    }];
    [[SDK910 sharedInstance] isCloseLoginViewWhenChangeAccount:NO];
#warning 1.30及以后版本请设置 appURLScheme
    [[SDK910 sharedInstance] setAppURLScheme:@"com.vxiyu.inapppay.demo"];
    
    [[SDK910 sharedInstance] addNotBackUpiCloud];
    
    [[SDK910 sharedInstance] showMemberCenter]; // 显示登陆界面，用户登陆成功后会回调到上面的 1
    
    NSLog(@"22222  mainScreenRect:%@\napplicationFrame:%@",NSStringFromCGRect([[UIScreen mainScreen] bounds]),NSStringFromCGRect([UIScreen mainScreen].applicationFrame));
    return YES;
}


#warning 1.30版本及以后的请添加下面两个
// 在XCode6 中如果nullable NSString *这种写法不支持，请换成 NSString *
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(nullable NSString *)sourceApplication annotation:(id)annotation {
    // ios 8 调用这里
    [[SDK910 sharedInstance] application:application openURL:url sourceApplication:sourceApplication annotation:annotation];
    return true;
}

// 在XCode6中 (NSDictionary<NSString*, id> *)options 不支持这种写法 请改成(NSDictionary *)options
- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary *)options{
    // ios 9 调用这里
    [[SDK910 sharedInstance] application:app openURL:url options:options];
    return true;
}

#warning 1.42以后请加下面4个
- (void)applicationDidEnterBackground:(UIApplication *)application {
    [[SDK910 sharedInstance] applicationDidEnterBackground:application];
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    [[SDK910 sharedInstance] applicationWillEnterForeground:application];
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    [[SDK910 sharedInstance] applicationDidBecomeActive:application];
}

- (void)applicationWillResignActive:(UIApplication *)application {
    [[SDK910 sharedInstance] applicationWillResignActive:application];
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    [[SDK910 sharedInstance] removeTransactionObserver];    // 移除支付监听
}

@end
