//
//  ViewController.m
//  SDKDemo
//
//  Created by 李振升 on 16/9/7.
//  Copyright (c) 2016年 武汉手盟网络科技有限公司. All rights reserved.
//

#import "ViewController.h"
#import <SM910APP/SM910APP.h>
#import "SSKeychain.h"
#import <SafariServices/SafariServices.h>

#define USER_SERVICE @"loginUserKeyService"
#define DEVICE_SERVICE @"DEVICEKeyService"
#define SMDEVICE_CODE @"SM910DEVICECode"
#define DEVICEID @"SMDEVICEID"
#define SMTRACK_SERVICE @"SM910TRACKKeyService"
#define GUEST_USER_SERVICE @"sm910guestLoginUserKeyService"
#define SM910BUGLYAPPID @"SM910BuglyAppID"
#define SMGUESTLOGINDATE @"SMGuestLoginDate"
#define SMGUESTLOGINTIMES @"SMGuestLoginTimes"

#define SMPAYKEYSERVICE @"sm910paykeyservices"
#define SMPAYKEYSERVICEPRICELANGUAGE @"sm910paykeyservicespricelanguage"
#define SMPAYKEYSERVICEPRICECURRENCY @"sm910paykeyservicespricecurrency"
#define SM910STARTAPP @"SM910STARTAPP1031"


@interface ViewController ()
{
    int times;
    UILabel *label;
    UILabel *versionLabel;
}



//@property (nonatomic, assign) enumProjectMemberRole enumProjectMemberRolepr;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self createUI];
    
    
}

-(void) createUI{
    [self.view setBackgroundColor:[UIColor whiteColor]];
    
    label=[[UILabel alloc]initWithFrame:CGRectMake(0, 20, [[UIScreen mainScreen] bounds].size.width, 50)];
    label.textAlignment=NSTextAlignmentCenter;
    NSString *welcome=[NSString stringWithFormat:@"欢迎来到九玩游戏%@版测试Demo",[[SDK910 sharedInstance]  currentVersion]];
    [label setText:welcome];
    [self.view addSubview:label];
    
    versionLabel=[[UILabel alloc]initWithFrame:CGRectMake(0, [[UIScreen mainScreen] bounds].size.height-50, [[UIScreen mainScreen] bounds].size.width, 50)];
    versionLabel.textAlignment=NSTextAlignmentCenter;
    NSString *versionText=[NSString stringWithFormat:@"SDK版本:%@",[[SDK910 sharedInstance]  currentVersion]];
    [versionLabel setText:versionText];
    [self.view addSubview:versionLabel];
    
    
    UITextField *textField=[[UITextField alloc] initWithFrame:CGRectMake((self.view.frame.size.width-100)/2.0, 90, 100, 30)];
    textField.tag=111;
    textField.text=@"0.01";
    textField.borderStyle=UITextBorderStyleRoundedRect;
    [self.view addSubview:textField];
    
    UIButton *payButton=[UIButton buttonWithType:UIButtonTypeSystem];
    [payButton setFrame:CGRectMake(50, 130, 100, 30)];
    [payButton setTitle:@"充值" forState:UIControlStateNormal];
    
    [payButton addTarget:self action:@selector(payAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:payButton];
    
    UIButton *payButton1=[UIButton buttonWithType:UIButtonTypeSystem];
    [payButton1 setFrame:CGRectMake(self.view.frame.size.width/2-50, 130, 100, 30)];
    [payButton1 setTitle:@"充值2" forState:UIControlStateNormal];
    
    [payButton1 addTarget:self action:@selector(payAction1) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:payButton1];
    
    UIButton *payButton2=[UIButton buttonWithType:UIButtonTypeSystem];
    [payButton2 setFrame:CGRectMake(self.view.frame.size.width-50, 130, 100, 30)];
    [payButton2 setTitle:@"充值3" forState:UIControlStateNormal];
    
    [payButton2 addTarget:self action:@selector(payAction2) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:payButton2];
    
    
    UIButton *showButton=[UIButton buttonWithType:UIButtonTypeSystem];
    [showButton setFrame:CGRectMake(self.view.frame.size.width/2-50, 180, 100, 30)];
    [showButton setTitle:@"重新登录" forState:UIControlStateNormal];
    
    [showButton addTarget:self action:@selector(showAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:showButton];
    
    
    UIButton *crashButton=[UIButton buttonWithType:UIButtonTypeSystem];
    [crashButton setFrame:CGRectMake(20, 180, 150, 30)];
    [crashButton setTitle:@"创建角色" forState:UIControlStateNormal];
    
//    [crashButton addTarget:self action:@selector(crashAction) forControlEvents:UIControlEventTouchUpInside];
    [crashButton addTarget:self action:@selector(createRoleAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:crashButton];
    
    UIButton *setRoleInfoButton=[UIButton buttonWithType:UIButtonTypeSystem];
    [setRoleInfoButton setFrame:CGRectMake(20, 230, 150, 30)];
    [setRoleInfoButton setTitle:@"设角色信息" forState:UIControlStateNormal];
    
    [setRoleInfoButton addTarget:self action:@selector(setRoleInfoAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:setRoleInfoButton];
    
    UIButton *crash1Button=[UIButton buttonWithType:UIButtonTypeSystem];
    [crash1Button setFrame:CGRectMake(220, 230, 150, 30)];
    [crash1Button setTitle:@"删除信息" forState:UIControlStateNormal];
    
    [crash1Button addTarget:self action:@selector(deleteGuestAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:crash1Button];
    
    UIButton *addCoinButton=[UIButton buttonWithType:UIButtonTypeSystem];
    [addCoinButton setFrame:CGRectMake(20, 275, 150, 30)];
    [addCoinButton setTitle:@"增加游戏币" forState:UIControlStateNormal];
    
    [addCoinButton addTarget:self action:@selector(addCoinAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:addCoinButton];
    
    UIButton *deleteCoinButton=[UIButton buttonWithType:UIButtonTypeSystem];
    [deleteCoinButton setFrame:CGRectMake(200, 275, 150, 30)];
    [deleteCoinButton setTitle:@"消耗游戏币" forState:UIControlStateNormal];
    
    [deleteCoinButton addTarget:self action:@selector(deleteCoinAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:deleteCoinButton];
    
    UIButton *testButton=[UIButton buttonWithType:UIButtonTypeSystem];
    [testButton setFrame:CGRectMake(380, 275, 150, 30)];
    [testButton setTitle:@"测试" forState:UIControlStateNormal];
    
    [testButton addTarget:self action:@selector(newurl) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:testButton];
    
    UITapGestureRecognizer *gestureRecognizer23=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(hideKeyBoard)];
    gestureRecognizer23.numberOfTapsRequired=2;
    gestureRecognizer23.numberOfTouchesRequired=1;
    
    [self.view addGestureRecognizer:gestureRecognizer23];
    
    
//    [self addChildViewController:childViewController];
}

-(void) payAction {
    UITextField *textField=[self.view viewWithTag:111];
    NSString *tex= textField.text;
    float ii=tex.floatValue;
    NSNumber *nub= [NSNumber numberWithFloat:ii];
    
#warning 请传商品ID与对应正确的金额
#warning  isChecked 提审状态 1为提审状态 0为正常状态,如果能按照审核状态和正式上线状态来设置，请传相应的值。如果不能请传 0
    [[SDK910 sharedInstance] startPayWithServerId:@"smpay" OrderId:@"923239829823" Amount:nub ProductId:@"gold" isChecked:0 payResult:^(SMPayResult result, NSString *message) {
        if (result==SMPayResultSuccess) {
            NSLog(@"支付成功:%@",message);
            
        }else{
            NSLog(@"支付失败:%@",message);
        }
        NSString *payTipText=[NSString stringWithFormat:@"支付结果:%@\t支付次数:%i",message,times];
        [self setTipText:payTipText];
    }];
    times++;
}

-(void) payAction1 {
    UITextField *textField=[self.view viewWithTag:111];
    NSString *tex= textField.text;
    float ii=tex.floatValue;
    NSNumber *nub= [NSNumber numberWithFloat:ii];
    
#warning 请传商品ID与对应正确的金额
#warning  isChecked 提审状态 1为提审状态 0为正常状态,如果能按照审核状态和正式上线状态来设置，请传相应的值。如果不能请传 0
    [[SDK910 sharedInstance] startPayWithServerId:@"smpay" OrderId:@"923239829823" Amount:nub ProductId:@"gold2" isChecked:0 payResult:^(SMPayResult result, NSString *message) {
        if (result==SMPayResultSuccess) {
            NSLog(@"支付成功:%@",message);
        }else{
            NSLog(@"支付失败:%@",message);
        }
        NSString *payTipText=[NSString stringWithFormat:@"支付结果:%@\t支付次数:%i",message,times];
        [self setTipText:payTipText];
    }];
    times++;
}

-(void) payAction2 {
    UITextField *textField=[self.view viewWithTag:111];
    NSString *tex= textField.text;
    float ii=tex.floatValue;
    NSNumber *nub= [NSNumber numberWithFloat:ii];
    
#warning 请传商品ID与对应正确的金额
#warning  isChecked 提审状态 1为提审状态 0为正常状态,如果能按照审核状态和正式上线状态来设置，请传相应的值。如果不能请传 0
    [[SDK910 sharedInstance] startPayWithServerId:@"smpay" OrderId:@"923239829823" Amount:nub ProductId:@"gold30" isChecked:0 payResult:^(SMPayResult result, NSString *message) {
        if (result==SMPayResultSuccess) {
            NSLog(@"支付成功:%@",message);
        }else{
            NSLog(@"支付失败:%@",message);
        }
        NSString *payTipText=[NSString stringWithFormat:@"支付结果:%@\t支付次数:%i",message,times];
        [self setTipText:payTipText];
    }];
    times++;
}

-(void) showAction {
    [[SDK910 sharedInstance] gameLogout];
    [[SDK910 sharedInstance] showMemberCenter];
}

-(void) crash1Action {
    NSArray *test=[[NSArray alloc]init];
    test[0];
}

-(void) hideKeyBoard {
    UITextField *textField=[self.view viewWithTag:111];
    [textField resignFirstResponder];
}

-(void)deleteGuestAction
{
    
    //删除userdefaults
    NSUserDefaults *defaults =[NSUserDefaults standardUserDefaults];
    
    [defaults setObject:nil forKey:@"guestname"];
    
     NSString *name = [SSKeychain passwordForService:USER_SERVICE account:GUEST_USER_SERVICE];
     BOOL success1 = [SSKeychain deletePasswordForService:USER_SERVICE account:GUEST_USER_SERVICE];
     BOOL success2 = [SSKeychain deletePasswordForService:USER_SERVICE account:name];
     BOOL success4 = [SSKeychain deletePasswordForService:DEVICE_SERVICE account:DEVICEID];
     BOOL success5 = [SSKeychain deletePasswordForService:SMPAYKEYSERVICE account:SMPAYKEYSERVICEPRICECURRENCY];
     BOOL success6 = [SSKeychain deletePasswordForService:SMPAYKEYSERVICE account:SMPAYKEYSERVICEPRICELANGUAGE];
    BOOL success7 = [SSKeychain deletePasswordForService:DEVICE_SERVICE account:SM910STARTAPP];
     BOOL success3 = [defaults synchronize];
     if (success1 && success2&&success3&&success4) {
     [self alertViewWithTitle:@"提示" message:@"删除成功！"];
     }else{
     [self alertViewWithTitle:@"提示" message:@"删除失败！"];
     }
    
//    [self showWebSite];
}

-(void)alertViewWithTitle:(NSString *)title message:(NSString *)message
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:message delegate:nil cancelButtonTitle:@"好的" otherButtonTitles:nil, nil];
    [alert show];
}

// 创建角色
-(void) createRoleAction {
    UITextField *textField=[self.view viewWithTag:111];
    NSString *roleName= textField.text;
    [[SDK910 sharedInstance] createRoleName:@"润物无声" roleId:@"99" withRoleServerId:@"182" roleServerName:@"无声"];
}

-(void)addCoinAction{
    [[SDK910 sharedInstance] addGameCoin:20];
}

-(void)deleteCoinAction{
    [[SDK910 sharedInstance] deleteGameCoin:10];
}

-(void)setRoleInfoAction{
    [[SDK910 sharedInstance] setRoleServerId:@"111" andRoleServerName:@"无声胜有声" andRoleId:@"999" andRoleName:@"润物无声" andRoleLevel:@"99" isCallRoleLevel:YES];
}

-(void) setRoleLevelAction{
    [[SDK910 sharedInstance] setRoleLevel:@"10"];
}

- (void)showWebSite {
    if ([[[UIDevice currentDevice] systemVersion] floatValue]>8.9) {
        NSURL *url = [NSURL URLWithString:@"https://myun.tenpay.com/mqq/pay"];
        SFSafariViewController *safariVC = [[SFSafariViewController alloc] initWithURL:url];
        [self showViewController:safariVC sender:nil];
    }else{
        
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}





#if OrientationIsPortrait
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation
{
    
    //    return (toInterfaceOrientation == UIInterfaceOrientationLandscapeLeft || toInterfaceOrientation == UIInterfaceOrientationLandscapeRight);
    
    return (toInterfaceOrientation == UIInterfaceOrientationPortrait || toInterfaceOrientation == UIInterfaceOrientationPortraitUpsideDown);
}
// For ios6 later, use supportedInterfaceOrientations & shouldAutorotate instead
-(UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    
    //    return UIInterfaceOrientationMaskLandscape;
    
    return (UIInterfaceOrientationMaskPortrait | UIInterfaceOrientationMaskPortraitUpsideDown);
    
}

- (BOOL)shouldAutorotate
{
    return YES;
}

#else

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation
{
    return (toInterfaceOrientation == UIInterfaceOrientationLandscapeLeft || toInterfaceOrientation == UIInterfaceOrientationLandscapeRight);
}
// For ios6 later, use supportedInterfaceOrientations & shouldAutorotate instead
-(UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskLandscape;
}

- (BOOL)shouldAutorotate
{
    return YES;
}

#endif

-(void) newurl {
    // https://appcashier.95516.com 银联
    // https://myun.tenpay.com/mqq/pay
    // mqqapiwallet:   调起QQAPP
    // weixin:  微信
    // alipay:		支付宝
    // https://wappaygw.alipay.com 支付宝
    [NSURL URLWithString:@"https://appcashier.95516.com"];
    [[NSURL alloc] initWithString:@"https://myun.tenpay.com/mqq/pay"];
    [NSURL URLWithString:@"mqqapiwallet:"];
    [NSURL URLWithString:@"weixin:"];
    [NSURL URLWithString:@"alipay:"];
    [NSURL URLWithString:@"https://wappaygw.alipay.com"];
    NSLog(@"%s",__func__);
    
}

-(void) setTipText:(NSString *)text{
    dispatch_async(dispatch_get_main_queue(), ^{
        label.text=text;
    });
    
}

@end
